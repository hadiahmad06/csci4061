#include <stdio.h>
#include <stdlib.h>

/*
 * Read the last integers from a binary file
 *   'num_ints': The number of integers to read
 *   'file_name': The name of the file to read from
 * Returns 0 on success and -1 on error
 */
#include <stdio.h>
#include <stdlib.h>

int read_last_ints(const char *file_name, int num_ints) {
    FILE *file = fopen(file_name, "rb");
    if (!file) {
        perror("Failed to open source file");
        return 1;
    }

    if (fseek(file, -num_ints * sizeof(int), SEEK_END) != 0) {
        perror("Failed to seek last integers");
        fclose(file);
        return -1;
    }

    int *buffer = (int *)malloc(num_ints * sizeof(int));
    if (!buffer) {
        perror("Memory allocation failed");
        fclose(file);
        return -1;
    }

    size_t count = fread(buffer, sizeof(int), num_ints, file);
    if (count < (size_t)num_ints) {
        perror("Error reading file");
        free(buffer);
        fclose(file);
        return -1;
    }

    for (int i = 0; i < num_ints; i++) {
        printf("%d\n", buffer[i]);
    }

    free(buffer);
    fclose(file);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <file_name> <num_ints>\n", argv[0]);
        return 1;
    }

    const char *file_name = argv[1];
    int num_ints = atoi(argv[2]);
    if (read_last_ints(file_name, num_ints) != 0) {
        printf("Failed to read last %d ints from file %s\n", num_ints, file_name);
        return 1;
    }
    return 0;
}
